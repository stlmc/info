class Proposition:
    def __init__(self, ):
        pass

    def make_consts(self):
        pass
